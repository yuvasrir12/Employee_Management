import express from "express";
import mongoose from "mongoose";
import cors from "cors";

const app = express();
const PORT = 5000;

// Middleware
app.use(express.json());
app.use(cors());

// --- Mongoose Connection ---
await mongoose.connect("mongodb://localhost:27017/Employees");
console.log("Connected to MongoDB");

// --- Define Schema & Model ---
const employeeSchema = new mongoose.Schema({
  EmployeeID: { type: String, required: true, unique: true },
  EmployeeName: { type: String, required: true },
  Designation: { type: String, required: true },
  Department: { type: String, required: true },
  JoiningDate: { type: String, required: true },
});

const Employee = mongoose.model("Employee", employeeSchema);

// --- CRUD ROUTES ---

// Add Employee (POST)
app.post("/employees", async (req, res) => {
  const { EmployeeID, EmployeeName, Designation, Department, JoiningDate } = req.body;

  try {
    const existing = await Employee.findOne({ EmployeeID });
    if (existing) return res.status(400).json({ error: "Employee already exists" });

    const employee = new Employee({
      EmployeeID,
      EmployeeName,
      Designation,
      Department,
      JoiningDate,
    });

    await employee.save();
    res.status(201).json(employee);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get all Employees (GET)
app.get("/employees", async (req, res) => {
  try {
    const employees = await Employee.find({}, { _id: 0, __v: 0 });
    res.json(employees);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Search Employee by ID (GET)
app.get("/employees/:id", async (req, res) => {
  try {
    const emp = await Employee.findOne({ EmployeeID: req.params.id }, { _id: 0, __v: 0 });
    if (!emp) return res.status(404).json({ error: "Employee not found" });
    res.json(emp);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Update Designation only (PUT)
app.put("/employees/:id", async (req, res) => {
  try {
    const result = await Employee.updateOne(
      { EmployeeID: req.params.id },
      { $set: { Designation: req.body.Designation } }
    );
    if (result.matchedCount === 0)
      return res.status(404).json({ error: "Employee not found" });
    res.json({ message: "Designation updated successfully" });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete("/employees/:id", async (req, res) => {
  try {
    // const { id } = req.params;
    const deletedEmployee = await Employee.findOneAndDelete({ EmployeeID: req.params.id});
    if (!deletedEmployee) {
      return res.status(404).json({ message: "Employee not found" });
    }
    res.json({ message: "Employee deleted successfully" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting employee", error });
  }
});



// --- Start Server ---
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});



